from django.apps import AppConfig


class CastleApartmentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Castle_Apartments'
